from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return render(request, 'index.html')
def slot(request):
    return render(request, 'slot.html')

def job(request):
    return render(request, 'job.html')